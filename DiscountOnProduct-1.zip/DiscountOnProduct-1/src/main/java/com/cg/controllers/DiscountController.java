package com.cg.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
import com.cg.service.ApplyDiscount;

@RestController
@RequestMapping("/")
public class DiscountController 
{
	@Autowired
	ApplyDiscount service;
	@PutMapping(value = "/applydiscount")
	public Product discountDB(@RequestParam int id) 
	{
		
		return service.discount(id);
	}
}

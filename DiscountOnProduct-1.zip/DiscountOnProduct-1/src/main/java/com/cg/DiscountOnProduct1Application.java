package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscountOnProduct1Application {

	public static void main(String[] args) {
		SpringApplication.run(DiscountOnProduct1Application.class, args);
	}

}

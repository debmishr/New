package com.cg.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@XmlRootElement
@Table(name="Discount")
public class Discount 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="DiscountId", length=10)
	private int discountID;
	@OneToOne()
	Product product;
	
	public Discount() {
		// TODO Auto-generated constructor stub
	}

	public Discount(int discountID, Product product) {
		super();
		this.discountID = discountID;
		this.product = product;
	}

	public int getDiscountID() {
		return discountID;
	}

	public void setDiscountID(int discountID) {
		this.discountID = discountID;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Discount [discountID=" + discountID + ", product=" + product + "]";
	}
	
}

package com.cg.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@XmlRootElement
@Table(name="Product")
public class Product 
{
	@Id@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ProductId", length=10)
	private int ProductId;
	@Column(name="ProductName", length=30)
	private String ProductName;
	@Column(name="ProductCost", length=10)
	private Double ProductCost;
	@Column(name="ProductQuantity", length=10)
	private double ProductQuantity;
	@Column(name="ProductCategory", length=30)
	private String ProductCategory;
	@Column(name="ProductCategory", length=10)
	private int Productdiscount;
	@Column(name="ProductFinalPrice", length=10)
	private Double ProductFinalPrice;
	
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, Double productCost, double productQuantity, String productCategory,
			int productdiscount,Double productfinalprice) {
		super();
		ProductId = productId;
		ProductName = productName;
		ProductCost = productCost;
		ProductQuantity = productQuantity;
		ProductCategory = productCategory;
		Productdiscount = productdiscount;
		ProductFinalPrice = productfinalprice;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		ProductId = productId;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}


	public double getProductQuantity() {
		return ProductQuantity;
	}

	public void setProductQuantity(double productQuantity) {
		ProductQuantity = productQuantity;
	}

	public String getProductCategory() {
		return ProductCategory;
	}

	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}

	public int getProductdiscount() {
		return Productdiscount;
	}

	public void setProductdiscount(int productdiscount) {
		Productdiscount = productdiscount;
	}

	
	

	public Double getProductCost() {
		return ProductCost;
	}

	public void setProductCost(Double productCost) {
		ProductCost = productCost;
	}

	public Double getProductFinalPrice() {
		return ProductFinalPrice;
	}

	public void setProductFinalPrice(Double productFinalPrice) {
		ProductFinalPrice = productFinalPrice;
	}

	@Override
	public String toString() {
		return "Product [ProductId=" + ProductId + ", ProductName=" + ProductName + ", ProductCost=" + ProductCost
				+ ", ProductQuantity=" + ProductQuantity + ", ProductCategory=" + ProductCategory + ", Productdiscount="
				+ Productdiscount + "]";
	}
	
	
}

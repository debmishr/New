package com.cg.service;
import org.springframework.stereotype.Repository;
import com.cg.entities.Discount;
import com.cg.entities.Product;
@Repository
public interface ApplyDiscount 
{
	public Product discount(int id);
	
}

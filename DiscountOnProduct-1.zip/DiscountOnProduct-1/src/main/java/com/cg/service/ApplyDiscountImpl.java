package com.cg.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.entities.Discount;
import com.cg.entities.Product;
import com.cg.repository.DiscountRepository;
@Service
public class ApplyDiscountImpl implements ApplyDiscount 
{
	@Autowired
	DiscountRepository repo;
	@Override
	public Product discount(int id) {
		// TODO Auto-generated method stub
		Optional<Product> opt = repo.findById(id);
		Product pd = opt.get();
		int discount = pd.getProductdiscount();
		Double price = pd.getProductCost();
		Double discountPrice = (price*discount)/100; 
		Double finalPrice = price-discountPrice;
		pd.setProductFinalPrice(finalPrice);
		repo.save(pd);
		return pd;
	}


}

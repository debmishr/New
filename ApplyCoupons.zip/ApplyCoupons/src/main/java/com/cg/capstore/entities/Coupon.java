package com.cg.capstore.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="couponscode")
@XmlRootElement
public class Coupon implements Serializable{
	
	@Id
	@Column(name="couponcode")
	private String couponcode;
	
	@Column(name="description")
	private String description;
	
	@Column(name="amount")
	private Double amount;
	
	@Column(name="expdate")
	private String expdate;
	
	@OneToOne()
	Product product;

	public Coupon(String couponcode, String description, Double amount, String expdate, Product product) {
		super();
		this.couponcode = couponcode;
		this.description = description;
		this.amount = amount;
		this.expdate = expdate;
		this.product = product;
	}

	public String getCouponcode() {
		return couponcode;
	}

	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getExpdate() {
		return expdate;
	}

	public void setExpdate(String expdate) {
		this.expdate = expdate;
	}

}

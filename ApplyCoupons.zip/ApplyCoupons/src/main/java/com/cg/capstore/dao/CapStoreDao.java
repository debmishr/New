package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capstore.entities.Coupon;


	@Repository
	public interface CapStoreDao extends JpaRepository<Coupon, String> {

	}


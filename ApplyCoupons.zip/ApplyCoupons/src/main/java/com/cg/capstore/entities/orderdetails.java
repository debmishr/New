package com.cg.capstore.entities;

public class orderdetails {

}

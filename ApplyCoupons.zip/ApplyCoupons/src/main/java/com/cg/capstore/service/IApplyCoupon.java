package com.cg.capstore.service;

import com.cg.capstore.entities.Coupon;

public interface IApplyCoupon {

 Coupon applyCoupon(String ccode);
 Coupon findByCouponCode(String ccode);

}

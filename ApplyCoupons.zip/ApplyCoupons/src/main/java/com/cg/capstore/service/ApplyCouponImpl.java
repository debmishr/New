package com.cg.capstore.service;

import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CapStoreDao;
import com.cg.capstore.dao.ProductDao;
import com.cg.capstore.entities.Coupon;
import com.cg.capstore.exception.ApplicationException;

@Service
@Transactional
public class ApplyCouponImpl implements IApplyCoupon {
	@Autowired private CapStoreDao dao;
	@Autowired private ProductDao pdao;
	
	@Transactional
	@Override
	public Coupon findByCouponCode(String ccode) {
		// TODO Auto-generated method stub
		System.out.println("Finding coupon: "+ccode);
		Optional<Coupon> temp = dao.findById(ccode);
		if(!temp.isPresent()) {
			throw new ApplicationException("Coupon not found "+ccode);
		}
		return temp.get();
	}
	
	
	
	@Transactional
	@Override
	public Coupon applyCoupon(String ccode) {
		// TODO Auto-generated method stub
		Coupon cp = findByCouponCode(ccode);	
		
		Product p=opt.
		String coupon = c.getCouponcode();
		Double couponamount = c.getAmount();
		Double price = ;
		Double finalPrice = price-discountPrice;
		pd.setProductFinalPrice(finalPrice);
		repo.save(pd);
		return pd;
		
	}
	
	

}
